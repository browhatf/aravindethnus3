
import './App.css';
import WordCount from './wordcount';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="App">
      <header class="font-weight-bold">Responsive Paragraph Word Counter</header>
    <WordCount/>
    </div>
  );
}

export default App;
